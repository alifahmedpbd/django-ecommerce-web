from .helpers import get_feature_toggles


def feature_toggles(request):

    return {

        "features": get_feature_toggles()

    }