
from django.shortcuts import render, redirect, get_object_or_404

from accounts.decorators import owner_or_staff_required

from accounts.models import User
from orders.models import Order, Coupon, OrderTimeline, ReturnRequest,Refund, Replacement, Exchange
from django.contrib import messages

from store.models import Category, Product, Brand, ProductImage
from .forms import CategoryForm, ProductForm, BrandForm, ProductImageForm, CouponForm, AnnouncementForm

from .decorators import owner_required
from django.core.paginator import Paginator

from django.db.models import Sum, Count, Q
from django.utils import timezone
from django.db.models.functions import TruncMonth

import json


from django.http import HttpResponse
from openpyxl import Workbook

from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph
from orders.models import ExchangeRate

from .models import FeatureToggle, Announcement, WebsiteSettings
from .helpers import clear_feature_cache
from django.views.decorators.http import require_POST
# Create your views here.


@owner_or_staff_required
def dashboard_home(request):

    total_orders = Order.objects.count()

    total_categories = Category.objects.count()

    total_customers = User.objects.filter(
        role="customer",
    ).count()

    total_products = Product.objects.count()

    revenue = (
        Order.objects.filter(
            status="delivered",
            paid=True,
        ).aggregate(
            total=Sum("final_total")
        )["total"] or 0
    )

    today = timezone.now().date()

    today_orders = Order.objects.filter(
        created_at__date=today,
    ).count()

    today_revenue = (
        Order.objects.filter(
            created_at__date=today,
            paid=True,
            status="delivered",
        ).aggregate(
            total=Sum("final_total"),
        )["total"] or 0
    )

    monthly_revenue = (

        Order.objects.filter(

            paid=True,

            status="delivered",

        )

        .annotate(

            month=TruncMonth("created_at"),

        )

        .values(

            "month",

        )

        .annotate(

            revenue=Sum("final_total"),

        )

        .order_by(

            "month",

        )

    )

    monthly_orders = (

        Order.objects.annotate(

            month=TruncMonth(

                "created_at"

            )

        )

        .values(

            "month"

        )

        .annotate(

            total=Count("id")

        )

        .order_by(

            "month"

        )

    )

    top_products = (
        Product.objects.only(
            "id",
            "name",
        )
        .annotate(
            total_sold=Sum("orderitem__quantity")
        )
        .order_by("-total_sold")[:5]
    )

    top_categories = (
        Category.objects.only(
            "id",
            "name",
        )
        .annotate(
            total_sold=Sum("products__orderitem__quantity")
        )
        .order_by("-total_sold")[:5]
    )


    recent_orders = Order.objects.select_related(
        "user",
    ).order_by(
        "-created_at",
    )[:5]

    recent_customers = User.objects.filter(
        role="customer",
    ).only(
        "id",
        "username",
        "email",
        "date_joined",
    ).order_by("-date_joined")[:5]

    low_stock_products = Product.objects.filter(
        stock__gt=0,
        stock__lte=5,
    ).only(
        "id",
        "name",
        "stock",
    )

    out_of_stock_products = Product.objects.filter(
        stock=0,
    ).only(
        "id",
        "name",
        "stock",
    )


    monthly_labels = [
        item["month"].strftime("%b %Y")
        for item in monthly_revenue
    ]

    monthly_revenue_data = [
        float(item["revenue"] or 0)
        for item in monthly_revenue
    ]

    monthly_order_data = [
        item["total"]
        for item in monthly_orders
    ]

    top_product_labels = [
        product.name
        for product in top_products
    ]

    top_product_data = [
        product.total_sold or 0
        for product in top_products
    ] 

    top_category_labels = [
        category.name
        for category in top_categories
    ]

    top_category_data = [
        category.total_sold or 0
        for category in top_categories
    ]


    payment_methods = (
        Order.objects.filter(
            paid=True,
            status="delivered",
        )
        .values("payment_method")
        .annotate(
            total=Sum("final_total"),
        )
    )

    payment_labels = [
        item["payment_method"].upper()
        for item in payment_methods
    ]

    payment_data = [
        float(item["total"] or 0)
        for item in payment_methods
    ]

    payment_method_labels = [
        item["payment_method"].upper()
        for item in payment_methods
    ]

    payment_method_data = [
        float(item["total"] or 0)
        for item in payment_methods
    ]

    

    best_customers = (

        User.objects.filter(
            role="customer",
        )

        .annotate(

            total_spent=Sum(
                "orders__final_total",
                filter=Q(
                    orders__paid=True,
                    orders__status="delivered",
                ),
            ),

            total_orders=Count(
                "orders",
                filter=Q(
                    orders__paid=True,
                    orders__status="delivered",
                ),
            ),

        )

        .filter(
            total_spent__isnull=False,
        )

        .order_by(
            "-total_spent",
        )[:5]

    )

    context = {

        "total_orders": total_orders,

        "total_categories": total_categories,

        "total_customers": total_customers,

        "total_products": total_products,

        "revenue": revenue,

        "today_orders": today_orders,

        "today_revenue": today_revenue,

        "monthly_revenue": monthly_revenue,

        "monthly_orders": monthly_orders,

        "top_products": top_products,

        "top_categories": top_categories,

        "recent_orders": recent_orders,

        "recent_customers": recent_customers,

        "low_stock_products": low_stock_products,

        "out_of_stock_products": out_of_stock_products,

        "low_stock_count": low_stock_products.count(),

        "out_of_stock_count": out_of_stock_products.count(),

        "monthly_labels": json.dumps(monthly_labels),
        "monthly_revenue_data": json.dumps(monthly_revenue_data), 
        "monthly_order_data": json.dumps(monthly_order_data),

        "top_product_labels": json.dumps(top_product_labels),
        "top_product_data": json.dumps(top_product_data),

        "top_category_labels": json.dumps(top_category_labels),
        "top_category_data": json.dumps(top_category_data),

        "payment_labels": json.dumps(payment_labels),

        "payment_data": json.dumps(payment_data),

        "payment_method_labels": json.dumps(payment_method_labels),
        "payment_method_data": json.dumps(payment_method_data),

        "best_customers": best_customers,

    }

    if request.user.role == "owner":

        return render(
            request,
            "dashboard/owner_dashboard.html",
            context,
        )

    if request.user.role == "staff":

        return render(
            request,
            "dashboard/staff_dashboard.html",
            context,
        )

    return redirect("home")


@owner_or_staff_required
def reports(request):

    revenue_by_payment = (

        Order.objects.filter(

            paid=True,
            status="delivered",

        )

        .values("payment_method")

        .annotate(

            total=Sum("final_total"),

            orders=Count("id"),

        )

    )

    best_customers = (

        User.objects.filter(

            role="customer",

        )

        .annotate(

            total_spent=Sum("orders__final_total"),

            total_orders=Count("orders"),

        )

        .order_by(

            "-total_spent",

        )[:10]

    )

    low_stock = Product.objects.filter(
        stock__lte=5,
    ).select_related(
        "category",
    )

    return render(

        request,

        "dashboard/reports.html",

        {

            "revenue_by_payment": revenue_by_payment,

            "best_customers": best_customers,

            "low_stock": low_stock,

        },

    )


@owner_or_staff_required
def sales_report_pdf(request):

    orders = (
        Order.objects
        .select_related(
            "user",
            "coupon",
        )
        .order_by("-created_at")
    )

    response = HttpResponse(
        content_type="application/pdf"
    )

    response["Content-Disposition"] = (
        'attachment; filename="sales_report.pdf"'
    )

    doc = SimpleDocTemplate(response)

    data = [[
        "Order",
        "Customer",
        "Date",
        "Payment",
        "Status",
        "Coupon",
        "Discount",
        "Total",
    ]]

    for order in orders:

        data.append([

            f"#{order.id}",

            order.user.username,

            order.created_at.strftime("%d-%m-%Y"),

            order.payment_method.upper(),

            order.status.title(),

            order.coupon.code if order.coupon else "-",

            f"${order.discount}",

            f"${order.final_total}",

        ])

    table = Table(data)

    table.setStyle(TableStyle([

        ("BACKGROUND",(0,0),(-1,0),colors.darkblue),
        ("TEXTCOLOR",(0,0),(-1,0),colors.white),

        ("GRID",(0,0),(-1,-1),1,colors.grey),

        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),

        ("BACKGROUND",(0,1),(-1,-1),colors.whitesmoke),

    ]))

    doc.build([table])

    return response


@owner_or_staff_required
def sales_report_excel(request):

    workbook = openpyxl.Workbook()

    sheet = workbook.active

    sheet.title = "Sales Report"

    sheet.append([

        "Order ID",

        "Customer",

        "Date",

        "Payment",

        "Status",

        "Coupon",

        "Discount",

        "Total",

    ])

    orders = (
        Order.objects
        .select_related(
            "user",
            "coupon",
        )
        .order_by("-created_at")
    )

    for order in orders:

        sheet.append([

            order.id,

            order.user.username,

            order.created_at.strftime("%d-%m-%Y"),

            order.payment_method,

            order.status,

            order.coupon.code if order.coupon else "",

            float(order.discount),

            float(order.final_total),

        ])

    response = HttpResponse(

        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    )

    response["Content-Disposition"] = (

        'attachment; filename="sales_report.xlsx"'

    )

    workbook.save(response)

    return response


def low_stock_report_pdf(request):

    response = HttpResponse(
        content_type="application/pdf"
    )

    response[
        "Content-Disposition"
    ] = 'attachment; filename="low_stock_report.pdf"'

    doc = SimpleDocTemplate(response)

    styles = getSampleStyleSheet()

    data = [

        [

            "Product",

            "Category",

            "Stock",

        ]

    ]

    products = Product.objects.filter(

        stock__lte=5

    ).select_related(

        "category"

    )

    for product in products:

        data.append([

            product.name,

            product.category.name,

            str(product.stock),

        ])

    table = Table(data)

    table.setStyle(

        TableStyle([

            ("GRID",(0,0),(-1,-1),1,colors.grey),

            ("BACKGROUND",(0,0),(-1,0),colors.black),

            ("TEXTCOLOR",(0,0),(-1,0),colors.white),

            ("BOTTOMPADDING",(0,0),(-1,0),8),

        ])

    )

    elements = [

        Paragraph(

            "Low Stock Report",

            styles["Heading1"]

        ),

        table,

    ]

    doc.build(elements)

    return response


def low_stock_report_excel(request):

    wb = Workbook()

    ws = wb.active

    ws.title = "Low Stock"

    ws.append([

        "Product",

        "Category",

        "Stock",

    ])

    products = Product.objects.filter(

        stock__lte=5

    ).select_related(

        "category"

    )

    for product in products:

        ws.append([

            product.name,

            product.category.name,

            product.stock,

        ])

    response = HttpResponse(

        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    )

    response[
        "Content-Disposition"

    ] = 'attachment; filename="low_stock.xlsx"'

    wb.save(response)

    return response


@owner_required
def category_list(request):

    categories = Category.objects.only(
        "id",
        "name",
    ).order_by("name")

    return render(
        request,
        "dashboard/categories/list.html",
        {
            "categories": categories,
        },
    )


@owner_required
def category_create(request):

    if request.method == "POST":

        form = CategoryForm(request.POST, request.FILES)

        if form.is_valid():

            form.save()

            messages.success(
                request,
                "Category created successfully.",
            )

            return redirect("dashboard:category_list")

    else:

        form = CategoryForm()

    return render(
        request,
        "dashboard/categories/create.html",
        {
            "form": form,
        },
    )


@owner_required
def category_update(request, pk):

    category = get_object_or_404(
        Category,
        pk=pk,
    )

    if request.method == "POST":

        form = CategoryForm(
            request.POST,
            request.FILES,
            instance=category,
        )

        if form.is_valid():

            form.save()

            messages.success(
                request,
                "Category updated successfully.",
            )

            return redirect("dashboard:category_list")

    else:

        form = CategoryForm(instance=category)

    return render(
        request,
        "dashboard/categories/update.html",
        {
            "form": form,
            "category": category,
        },
    )


@owner_required
def category_delete(request, pk):

    category = get_object_or_404(
        Category,
        pk=pk,
    )

    category.delete()

    messages.success(
        request,
        "Category deleted successfully.",
    )

    return redirect("dashboard:category_list")


# ==========================================
# Brand List
# ==========================================

def brand_list(request):

    brands = Brand.objects.order_by("name")

    return render(
        request,
        "dashboard/brands/list.html",
        {
            "brands": brands,
        },
    )


# ==========================================
# Brand Create
# ==========================================

def brand_create(request):

    if request.method == "POST":

        form = BrandForm(
            request.POST,
            request.FILES,
        )

        if form.is_valid():

            form.save()

            messages.success(
                request,
                "Brand Added Successfully.",
            )

            return redirect("dashboard:brand_list")

    else:

        form = BrandForm()

    return render(
        request,
        "dashboard/brands/create.html",
        {
            "form": form,
        },
    )


# ==========================================
# Brand Update
# ==========================================

def brand_update(request, pk):

    brand = get_object_or_404(
        Brand,
        pk=pk,
    )

    if request.method == "POST":

        form = BrandForm(
            request.POST,
            request.FILES,
            instance=brand,
        )

        if form.is_valid():

            form.save()

            messages.success(
                request,
                "Brand Updated Successfully.",
            )

            return redirect("dashboard:brand_list")

    else:

        form = BrandForm(
            instance=brand,
        )

    return render(
        request,
        "dashboard/brands/update.html",
        {
            "form": form,
        },
    )


# ==========================================
# Brand Delete
# ==========================================

def brand_delete(request, pk):

    brand = get_object_or_404(Brand, pk=pk)

    if request.method == "POST":

        brand.delete()

        messages.success(
            request,
            "Brand Deleted Successfully.",
        )

        return redirect("dashboard:brand_list")

    return render(
        request,
        "dashboard/brands/delete.html",
        {
            "brand": brand,
        },
    )


# ==========================================
# Product List
# ==========================================
@owner_required



def product_list(request):

    query = request.GET.get("q")

    products = (
        Product.objects
        .select_related(
            "category",
            "brand",
        )
        .order_by("-created_at")
    )

    if query:

        products = products.filter(
            name__icontains=query
        )

    paginator = Paginator(
        products,
        10,
    )

    page_number = request.GET.get("page")

    page_obj = paginator.get_page(page_number)

    context = {

        "page_obj": page_obj,

        "products": page_obj,

        "query": query,

        "total_products": Product.objects.count(),

        "available_products": Product.objects.filter(
            available=True
        ).count(),

        "featured_products": Product.objects.filter(
            featured=True
        ).count(),

        "out_of_stock": Product.objects.filter(
            stock=0
        ).count(),

    }

    return render(
        request,
        "dashboard/products/list.html",
        context,
    )

# ==========================================
# Product Create
# ==========================================
@owner_required
def product_create(request):

    if request.method == "POST":

        form = ProductForm(
            request.POST,
            request.FILES,
        )

        if form.is_valid():

            form.save()

            messages.success(
                request,
                "Product created successfully.",
            )

            return redirect("dashboard:product_list")

    else:

        form = ProductForm()

    return render(
        request,
        "dashboard/products/create.html",
        {

            "form": form,

        },
    )


# ==========================================
# Product Update
# ==========================================
@owner_required
def product_update(request, pk):

    product = get_object_or_404(
        Product,
        pk=pk,
    )

    if request.method == "POST":

        form = ProductForm(
            request.POST,
            request.FILES,
            instance=product,
        )

        if form.is_valid():

            form.save()

            messages.success(
                request,
                "Product updated successfully.",
            )

            return redirect("dashboard:product_list")

    else:

        form = ProductForm(
            instance=product,
        )

    return render(
        request,
        "dashboard/products/update.html",
        {

            "form": form,

            "product": product,

        },
    )


# ==========================================
# Product Delete
# ==========================================
@owner_required
def product_delete(request, pk):

    product = get_object_or_404(
        Product,
        pk=pk,
    )

    if request.method == "POST":

        product.delete()

        messages.success(
            request,
            "Product deleted successfully.",
        )

        return redirect("dashboard:product_list")

    return render(
        request,
        "dashboard/products/delete.html",
        {

            "product": product,

        },
    )



# ==========================================
# Product Gallery
# ==========================================

def product_gallery(request, pk):

    product = get_object_or_404(
        Product,
        pk=pk,
    )

    images = product.gallery.only(
        "id",
        "image",
    )

    form = ProductImageForm()

    context = {

        "product": product,

        "images": images,

        "form": form,

    }

    return render(

        request,

        "dashboard/product_images/gallery.html",

        context,

    )



# ==========================================
# Upload Product Image
# ==========================================

def product_image_create(request, pk):

    product = get_object_or_404(

        Product,

        pk=pk,

    )

    if request.method == "POST":

        form = ProductImageForm(

            request.POST,

            request.FILES,

        )

        if form.is_valid():

            image = form.save(

                commit=False,

            )

            image.product = product

            image.save()

            messages.success(

                request,

                "Image Uploaded Successfully.",

            )

    return redirect(

        "dashboard:product_gallery",

        pk=pk,

    )


# ==========================================
# Delete Product Image
# ==========================================

def product_image_delete(request, pk):

    image = get_object_or_404(

        ProductImage,

        pk=pk,

    )

    product_id = image.product.id

    image.delete()

    messages.success(

        request,

        "Image Deleted Successfully.",

    )

    return redirect(

        "dashboard:product_gallery",

        pk=product_id,

    )


# ==========================================
# Coupon List
# ==========================================

def coupon_list(request):

    coupons = Coupon.objects.only(
        "id",
        "code",
        "discount",
        "active",
        "valid_from",
        "valid_to",
    ).order_by("-id")

    return render(

        request,

        "dashboard/coupon/list.html",

        {

            "coupons": coupons,

        },

    )


# ==========================================
# Coupon Add
# ==========================================

def coupon_add(request):

    if request.method == "POST":

        form = CouponForm(request.POST)

        if form.is_valid():

            form.save()

            return redirect("dashboard:coupon_list")

    else:

        form = CouponForm()

    return render(

        request,

        "dashboard/coupon/form.html",

        {

            "form": form,

            "title": "Add Coupon",

        },

    )


# ==========================================
# Coupon Edit
# ==========================================

def coupon_edit(request, pk):

    coupon = get_object_or_404(

        Coupon,

        pk=pk,

    )

    if request.method == "POST":

        form = CouponForm(

            request.POST,

            instance=coupon,

        )

        if form.is_valid():

            form.save()

            return redirect(

                "dashboard:coupon_list"

            )

    else:

        form = CouponForm(

            instance=coupon,

        )

    return render(

        request,

        "dashboard/coupon/form.html",

        {

            "form": form,

            "title": "Edit Coupon",

        },

    )


# ==========================================
# Coupon Delete
# ==========================================

def coupon_delete(request, pk):

    coupon = get_object_or_404(

        Coupon,

        pk=pk,

    )

    coupon.delete()

    return redirect(

        "dashboard:coupon_list"

    )

@owner_or_staff_required
def dashboard_order_detail(request, order_id):

    order = get_object_or_404(
        Order.objects.select_related(
            "user",
            "coupon",
        ).prefetch_related(
            "items__product",
            "timeline__user",
        ),
        id=order_id,
    )

    if request.method == "POST":

        # ====================================================
        # Add Timeline Only
        # ====================================================

        if "note" in request.POST and request.POST.get("note").strip():

            OrderTimeline.objects.create(

                order=order,

                user=request.user,

                created_by=request.user.username,

                note=request.POST.get("note"),

            )

            messages.success(
                request,
                "Timeline note added successfully."
            )

            return redirect(
                "dashboard:dashboard_order_detail",
                order.id,
            )

        # ====================================================
        # Previous Values
        # ====================================================

        old_status = order.status
        old_payment = order.payment_status

        old_tracking = order.tracking_number
        old_courier = order.courier_name
        old_delivery = order.estimated_delivery

        # ====================================================
        # Payment
        # ====================================================

        order.payment_status = request.POST.get(
            "payment_status",
            order.payment_status,
        )

        order.paid = order.payment_status in [
            "paid",
            "partial",
        ]

        # ====================================================
        # Order Status
        # ====================================================

        order.status = request.POST.get(
            "status",
            order.status,
        )

        # ====================================================
        # Courier
        # ====================================================

        order.courier_name = request.POST.get(
            "courier_name",
            "",
        )

        order.delivery_charge = (
            request.POST.get("delivery_charge")
            or 0
        )

        estimated = request.POST.get(
            "estimated_delivery"
        )

        if estimated:

            order.estimated_delivery = estimated

        # ====================================================
        # Save
        # ====================================================

        order.save()
        order.refresh_from_db()

        # ====================================================
# Return Request Update
# ====================================================


        if hasattr(order, "return_request"):


            return_status = request.POST.get("return_status")

            if return_status:

                request_obj = order.return_request

                old_return_status = request_obj.status

                request_obj.status = return_status

                request_obj.admin_note = request.POST.get(
                "return_admin_note",
                request_obj.admin_note,
                )

                request_obj.resolution = request.POST.get(
                    "resolution",
                    request_obj.resolution,
                )

                request_obj.save()

        # ==========================================
        # Timeline
        # ==========================================

                if old_return_status != return_status:

                    OrderTimeline.objects.create(
                        order=order,
                        user=request.user,
                        created_by=request.user.username,
                        note=(
                        f"Return request changed "
                        f"from '{old_return_status}' "
                        f"to '{return_status}'."
                    ),
                )

        # ==========================================
        # Refund Queue
        # ==========================================

                if (
                    return_status == "approved"
                    and request_obj.resolution == "refund"
                ):

                    Refund.objects.get_or_create(
                        return_request=request_obj,
                        defaults={
                        "order": order,
                        "amount": order.final_total,
                        "status": "pending",
                        },
                    )

                    OrderTimeline.objects.create(
                        order=order,
                        user=request.user,
                        created_by=request.user.username,
                        note="💰 Refund request sent to Refund Center.",
                    )

        # ==========================================
        # Exchange Queue
        # ==========================================

                elif (
                    return_status == "approved"
                    and request_obj.resolution == "exchange"
                ):

                    first_item = order.items.first()

                    Exchange.objects.get_or_create(
                        return_request=request_obj,
                        defaults={
                        "order": order,
                        "old_product": first_item.product if first_item else None,
                        "quantity": first_item.quantity if first_item else 1,
                        },
                    )

                    OrderTimeline.objects.create(
                        order=order,
                        user=request.user,
                        created_by=request.user.username,
                        note="🔄 Exchange request sent to Exchange Center.",
                    )

        # ==========================================
        # Replacement Queue
        # ==========================================

                elif (
                    return_status == "approved"
                    and request_obj.resolution == "replacement"
                ):

                    Replacement.objects.get_or_create(
                    return_request=request_obj,
                    defaults={
                    "old_order": order,
                    },
                )

                    OrderTimeline.objects.create(
                        order=order,
                        user=request.user,
                        created_by=request.user.username,
                        note="📦 Replacement request sent to Replacement Center.",
                    )

        # ====================================================
        # Tracking Timeline
        # ====================================================

        if old_tracking != order.tracking_number and order.tracking_number:

            OrderTimeline.objects.create(

                order=order,

                user=request.user,

                created_by=request.user.username,

                note=f"📍 Tracking Number Added : {order.tracking_number}",

            )


        if old_courier != order.courier_name and order.courier_name:

            OrderTimeline.objects.create(

                order=order,

                user=request.user,

                created_by=request.user.username,

                note=f"🚚 Courier Assigned : {order.courier_name}",

            )


        if old_delivery != order.estimated_delivery and order.estimated_delivery:

            OrderTimeline.objects.create(

                order=order,

                user=request.user,

                created_by=request.user.username,

                note=f"📅 Estimated Delivery : {order.estimated_delivery}",

            )

        # ====================================================
        # Admin Note -> Timeline
        # ====================================================

        admin_note = request.POST.get("admin_note")

        if admin_note:

            OrderTimeline.objects.create(

                order=order,

                user=request.user,

                created_by=request.user.username,

                note=admin_note,

            )

        # ====================================================
        # Timeline Auto Log
        # ====================================================

        if old_status != order.status:

            STATUS_MESSAGES = {
                "pending": "📦 Order placed.",
                "processing": "⚙️ Order is being processed.",
                "shipped": f"🚚 Order shipped via {order.courier_name}.",
                "delivered": "✅ Order delivered successfully.",
                "cancelled": "❌ Order cancelled.",
            }

            OrderTimeline.objects.create(

                order=order,

                user=request.user,

                created_by=request.user.username,

                note=STATUS_MESSAGES.get(order.status, order.status),

            )

        if old_payment != order.payment_status:

            PAYMENT_MESSAGES = {
                "pending": "💳 Payment Pending.",
                "partial": "💰 Partial Payment Received.",
                "paid": "✅ Payment Completed.",
                "failed": "❌ Payment Failed.",
                "refunded": "↩️ Payment Refunded.",
            }

            OrderTimeline.objects.create(

                order=order,

                user=request.user,

                created_by=request.user.username,

                note=PAYMENT_MESSAGES.get(order.payment_status),

            )

        # ====================================================
        # Email
        # ====================================================

        from payments.utils import (
            send_shipping_email,
            send_delivered_email,
            send_cancelled_email,
        )

        # Send Shipping Email
        if (
            order.status == "shipped"
            and (
                old_status != order.status
                or old_courier != order.courier_name
                or old_tracking != order.tracking_number
                or old_delivery != order.estimated_delivery
            )
        ):
            send_shipping_email(request, order)

        # Delivered Email
        if (
            old_status != order.status
                and order.status == "delivered"
        ):
            send_delivered_email(request, order)

        # Cancelled Email
        if (
            old_status != order.status
                and order.status == "cancelled"
            ):
            send_cancelled_email(request, order)

        messages.success(

            request,

            "Order updated successfully."

        )

        return redirect(

            "dashboard:dashboard_order_detail",

            order.id,

        )

    return render(

        request,

        "dashboard/order_detail.html",

        {

            "order": order,

        },

    )


@owner_or_staff_required
def dashboard_orders(request):

    orders = Order.objects.select_related(
        "user"
    ).order_by(
        "-created_at"
    )

    # ==========================
    # Search
    # ==========================

    q = request.GET.get("q")

    if q:

        orders = orders.filter(

            Q(id__icontains=q)

            |

            Q(full_name__icontains=q)

            |

            Q(email__icontains=q)

            |

            Q(phone__icontains=q)

        )

    # ==========================
    # Status
    # ==========================

    status = request.GET.get("status")

    if status:

        orders = orders.filter(
            status=status
        )

    # ==========================
    # Payment Method
    # ==========================

    payment = request.GET.get("payment")

    if payment:

        orders = orders.filter(
            payment_method=payment
        )

    # ==========================
    # Paid
    # ==========================

    paid = request.GET.get("paid")

    if paid == "yes":

        orders = orders.filter(
            paid=True
        )

    elif paid == "no":

        orders = orders.filter(
            paid=False
        )

    # ==========================
    # Pagination
    # ==========================

    paginator = Paginator(
        orders,
        20,
    )

    page_number = request.GET.get("page")

    page_obj = paginator.get_page(page_number)

    return render(

        request,

        "dashboard/orders.html",

        {

            "orders": page_obj,

            "page_obj": page_obj,

        },

    )


@owner_or_staff_required
def export_orders_excel(request):

    wb = Workbook()

    ws = wb.active

    ws.title = "Orders"

    ws.append([
        "Order ID",
        "Customer",
        "Email",
        "Phone",
        "Total",
        "Payment",
        "Payment Status",
        "Order Status",
        "Courier",
        "Tracking",
        "Date",
    ])

    orders = Order.objects.select_related(
        "user"
    ).order_by(
        "-created_at"
    )

    for order in orders:

        ws.append([

            order.id,

            order.full_name,

            order.email,

            order.phone,

            float(order.final_total),

            order.payment_method,

            order.payment_status,

            order.status,

            order.courier_name,

            order.tracking_number,

            order.created_at.strftime("%d-%m-%Y %H:%M"),

        ])

    response = HttpResponse(

        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    )

    response["Content-Disposition"] = (
        'attachment; filename="orders.xlsx"'
    )

    wb.save(response)

    return response

@owner_or_staff_required
def low_stock_report(request):

    products = Product.objects.filter(stock__lte=5)

    return render(
        request,
        "dashboard/low_stock_report.html",
        {
            "products": products,
        },
    )


@owner_or_staff_required
def dashboard_customers(request):

    customers = (
        User.objects.filter(
            role="customer",
        ).only(
            "id",
            "username",
            "email",
            "date_joined",
        )
        .annotate(
            total_orders=Count("orders"),
            total_spent=Sum("orders__final_total"),
        )
        .order_by("-date_joined")
    )

    return render(
        request,
        "dashboard/customers.html",
        {
            "customers": customers,
        },
    )


@owner_or_staff_required
def dashboard_customer_detail(request, user_id):

    customer = get_object_or_404(
        User,
        id=user_id,
        role="customer",
    )

    orders = customer.orders.select_related(
        "coupon",
    ).order_by(
        "-created_at",
    )

    total_spent = (
        orders.filter(
            paid=True,
            status="delivered",
        ).aggregate(
            total=Sum("final_total"),
        )["total"] or 0
    )

    context = {

        "customer": customer,

        "orders": orders,

        "total_spent": total_spent,

    }

    return render(
        request,
        "dashboard/customer_detail.html",
        context,
    )

@owner_or_staff_required
def currency_exchange(request):

    exchange_rate, created = ExchangeRate.objects.get_or_create(
        currency="USD",
        defaults={
            "rate": 122.50,
        },
    )

    if request.method == "POST":

        exchange_rate.rate = request.POST.get("rate")
        exchange_rate.save()

        messages.success(
            request,
            "USD exchange rate updated successfully.",
        )

        return redirect("dashboard:home")

    return render(
        request,
        "dashboard/currency_exchange.html",
        {
            "exchange_rate": exchange_rate,
        },
    )

@owner_or_staff_required
def feature_toggle_list(request):

    defaults = [

        {
            "key": "flash_sale",
            "category": "marketing",
            "icon": "bi bi-lightning-charge-fill",
            "description": "Enable flash sale products.",
        },

        {
            "key": "free_delivery",
            "category": "marketing",
            "icon": "bi bi-truck",
            "description": "Show free delivery offers.",
        },

        {
            "key": "new_arrival",
            "category": "products",
            "icon": "bi bi-stars",
            "description": "Display new arrival section.",
        },

        {
            "key": "trending",
            "category": "products",
            "icon": "bi bi-fire",
            "description": "Display trending products.",
        },

        {
            "key": "guest_checkout",
            "category": "checkout",
            "icon": "bi bi-person",
            "description": "Allow guest checkout.",
        },

        {
            "key": "wishlist",
            "category": "website",
            "icon": "bi bi-heart",
            "description": "Enable wishlist feature.",
        },

        {
            "key": "reviews",
            "category": "website",
            "icon": "bi bi-chat-left-text",
            "description": "Allow product reviews.",
        },

        {
            "key": "coupon",
            "category": "checkout",
            "icon": "bi bi-ticket",
            "description": "Enable coupon system.",
        },

        {
            "key": "cod",
            "category": "payment",
            "icon": "bi bi-cash-stack",
            "description": "Cash On Delivery payment.",
        },

        {
            "key": "emi",
            "category": "payment",
            "icon": "bi bi-credit-card",
            "description": "Enable EMI payment.",
        },

        {
            "key": "maintenance",
            "category": "website",
            "icon": "bi bi-tools",
            "description": "Put website into maintenance mode.",
        },

        {
            "key": "coming_soon",
            "category": "website",
            "icon": "bi bi-hourglass-split",
            "description": "Show coming soon page.",
        },

        {
            "key": "announcement",
            "category": "marketing",
            "icon": "bi bi-megaphone",
            "description": "Display announcement bar.",
        },

    ]

    for item in defaults:

        FeatureToggle.objects.update_or_create(

            key=item["key"],

            defaults={

                "category": item["category"],

                "icon": item["icon"],

                "description": item["description"],

            },

        )

    if request.method == "POST":

        feature = get_object_or_404(
            FeatureToggle,
            id=request.POST.get("id"),
        )

        feature.enabled = not feature.enabled

        feature.updated_by = request.user

        feature.save()

        clear_feature_cache()

        messages.success(
            request,
            f"{feature.get_key_display()} updated successfully.",
        )

        return redirect("dashboard:feature_toggle_list")

    category = request.GET.get("category")

    features = FeatureToggle.objects.all()

    if category:
        features = features.filter(category=category)

    return render(

        request,

        "dashboard/feature_toggle_list.html",

        {

            "features": features,

            "active_category": category,

            "categories": FeatureToggle.CATEGORY_CHOICES,

        },

    )


@owner_required
def website_features(request):

    settings = WebsiteSettings.load()

    if request.method == "POST":

        settings.shop_name = request.POST.get("shop_name")
        settings.shop_tagline = request.POST.get("shop_tagline")

        settings.announcement = request.POST.get("announcement")

        settings.phone = request.POST.get("phone")
        settings.email = request.POST.get("email")
        settings.address = request.POST.get("address")

        settings.facebook = request.POST.get("facebook")
        settings.instagram = request.POST.get("instagram")
        settings.youtube = request.POST.get("youtube")
        settings.linkedin = request.POST.get("linkedin")
        settings.twitter = request.POST.get("twitter")

        settings.footer_text = request.POST.get("footer_text")
        settings.copyright = request.POST.get("copyright")

        if request.FILES.get("logo"):
            settings.logo = request.FILES["logo"]

        if request.FILES.get("favicon"):
            settings.favicon = request.FILES["favicon"]

        settings.save()

        messages.success(request, "Website settings updated successfully.")
        return redirect("dashboard:website_features")

    return render(
        request,
        "dashboard/website_features.html",
        {
            "settings": settings,
        },
    )

@owner_required
def announcement_list(request):

    announcements = Announcement.objects.all()

    return render(
        request,
        "dashboard/announcement/list.html",
        {
            "announcements": announcements,
        },
    )


@owner_required
def announcement_add(request):

    if request.method == "POST":

        form = AnnouncementForm(request.POST)

        if form.is_valid():

            form.save()

            messages.success(
                request,
                "Announcement added successfully.",
            )

            return redirect("dashboard:announcement_list")

    else:

        form = AnnouncementForm()

    return render(
        request,
        "dashboard/announcement/form.html",
        {
            "form": form,
            "title": "Add Announcement",
        },
    )


@owner_required
def announcement_edit(request, pk):

    announcement = get_object_or_404(
        Announcement,
        pk=pk,
    )

    if request.method == "POST":

        form = AnnouncementForm(
            request.POST,
            instance=announcement,
        )

        if form.is_valid():

            form.save()

            messages.success(
                request,
                "Announcement updated successfully.",
            )

            return redirect("dashboard:announcement_list")

    else:

        form = AnnouncementForm(
            instance=announcement,
        )

    return render(
        request,
        "dashboard/announcement/form.html",
        {
            "form": form,
            "title": "Edit Announcement",
        },
    )

@owner_required
def announcement_delete(request, pk):

    announcement = get_object_or_404(
        Announcement,
        pk=pk,
    )

    if request.method == "POST":

        announcement.delete()

        messages.success(
            request,
            "Announcement deleted successfully.",
        )

        return redirect("dashboard:announcement_list")

    return render(
        request,
        "dashboard/announcement/delete.html",
        {
            "announcement": announcement,
        },
    )

@owner_or_staff_required
def dashboard_returns(request):

    status = request.GET.get("status")

    returns = (
        ReturnRequest.objects
        .select_related("order", "user")
        .order_by("-created_at")
    )

    if status:
        returns = returns.filter(status=status)

    paginator = Paginator(returns, 10)   # প্রতি পেজে 10টি

    page_number = request.GET.get("page")

    page_obj = paginator.get_page(page_number)

    context = {
        "returns": page_obj,

        "page_obj": page_obj,

        "pending_count": ReturnRequest.objects.filter(status="pending").count(),
        "approved_count": ReturnRequest.objects.filter(status="approved").count(),
        "rejected_count": ReturnRequest.objects.filter(status="rejected").count(),
        "refunded_count": ReturnRequest.objects.filter(status="refunded").count(),
        "all_count": ReturnRequest.objects.count(),
    }

    return render(
        request,
        "dashboard/returns.html",
        context,
    )

@owner_or_staff_required
def dashboard_refunds(request):

    status = request.GET.get("status")

    refunds = (
        Refund.objects
        .select_related(
            "order",
            "return_request",
            "completed_by",
        )
        .order_by("-created_at")
    )

    if status:
        refunds = refunds.filter(status=status)

    paginator = Paginator(refunds, 20)

    page = request.GET.get("page")

    refunds = paginator.get_page(page)

    context = {
        "refunds": refunds,
        "page_obj": refunds,

        "pending_count": Refund.objects.filter(status="pending").count(),

        "processing_count": Refund.objects.filter(status="processing").count(),

        "completed_count": Refund.objects.filter(status="completed").count(),

        "cancelled_count": Refund.objects.filter(status="cancelled").count(),

        "total_amount": Refund.objects.filter(
            status="completed"
            ).aggregate(
            total=Sum("amount")
        )["total"] or 0,
    }

    return render(
        request,
        "dashboard/refunds.html",
        context,
    )


@owner_or_staff_required
def dashboard_refund_detail(request, pk):

    refund = get_object_or_404(
        Refund.objects.select_related(
            "order",
            "return_request",
        ),
        pk=pk,
    )

    return render(
        request,
        "dashboard/refund_detail.html",
        {
            "refund": refund,
        },
    )

@require_POST
@owner_or_staff_required
def complete_refund(request, pk):

    refund = get_object_or_404(
        Refund.objects.select_related(
            "order",
            "return_request",
        ),
        pk=pk,
    )

    # Already completed
    if refund.status == "completed":

        messages.warning(
            request,
            "Refund already completed.",
        )

        return redirect(
            "dashboard:dashboard_refund_detail",
            refund.id,
        )

    # Cancelled refund cannot be completed
    if refund.status == "cancelled":

        messages.error(
            request,
            "Cancelled refund cannot be completed.",
        )

        return redirect(
            "dashboard:dashboard_refund_detail",
            refund.id,
        )

    # ==========================================
    # Refund
    # ==========================================

    refund.status = "completed"
    refund.completed_at = timezone.now()
    refund.completed_by = request.user

    refund.admin_note = request.POST.get(
        "admin_note",
        refund.admin_note,
    )

    refund.refund_method = request.POST.get(
        "refund_method",
        refund.refund_method,
    )

    refund.transaction_id = request.POST.get(
        "transaction_id",
        refund.transaction_id,
    )

    refund.save()

    # ==========================================
    # Order
    # ==========================================

    order = refund.order

    order.payment_status = "refunded"
    order.status = "cancelled"

    order.save(
        update_fields=[
            "payment_status",
            "status",
        ]
    )

    # ==========================================
    # Return Request
    # ==========================================

    refund.return_request.status = "refunded"
    refund.return_request.admin_note = refund.admin_note

    refund.return_request.save(
        update_fields=[
            "status",
            "admin_note",
            "updated_at",
        ]
    )

    # ==========================================
    # Timeline
    # ==========================================

    OrderTimeline.objects.create(
        order=order,
        user=request.user,
        created_by=request.user.username,
        note=(
            "💰 Refund completed successfully.\n\n"
            f"Refund Method : {refund.get_refund_method_display()}\n"
            f"Transaction ID : {refund.transaction_id or 'N/A'}"
        ),
    )

    messages.success(
        request,
        "Refund completed successfully.",
    )

    return redirect(
        "dashboard:dashboard_refund_detail",
        refund.id,
    )

@require_POST
@owner_or_staff_required
def cancel_refund(request, pk):

    refund = get_object_or_404(
        Refund.objects.select_related(
            "order",
            "return_request",
        ),
        pk=pk,
    )

    # Already completed
    if refund.status == "completed":

        messages.error(
            request,
            "Completed refund cannot be cancelled.",
        )

        return redirect(
            "dashboard:dashboard_refund_detail",
            refund.id,
        )

    refund.status = "cancelled"

    refund.admin_note = request.POST.get(
        "admin_note",
        refund.admin_note,
    )

    refund.save(
        update_fields=[
            "status",
            "admin_note",
        ]
    )

    refund.return_request.status = "approved"
    refund.return_request.admin_note = refund.admin_note

    refund.return_request.save(
        update_fields=[
            "status",
            "admin_note",
            "updated_at",
        ]
    )

    OrderTimeline.objects.create(
        order=refund.order,
        user=request.user,
        created_by=request.user.username,
        note="❌ Refund request cancelled by admin.",
    )

    messages.success(
        request,
        "Refund cancelled successfully.",
    )

    return redirect(
        "dashboard:dashboard_refund_detail",
        refund.id,
    )

@owner_or_staff_required
def dashboard_exchanges(request):

    status = request.GET.get("status")

    exchanges = (
        Exchange.objects
        .select_related(
            "order",
            "old_product",
            "new_product",
            "return_request",
            "completed_by",
        )
        .order_by("-created_at")
    )

    if status:
        exchanges = exchanges.filter(status=status)

    paginator = Paginator(exchanges, 20)

    page = request.GET.get("page")

    page_obj = paginator.get_page(page)

    context = {
        "exchanges": page_obj,
        "page_obj": page_obj,

        "pending_count": Exchange.objects.filter(status="pending").count(),
        "approved_count": Exchange.objects.filter(status="approved").count(),
        "processing_count": Exchange.objects.filter(status="processing").count(),
        "shipped_count": Exchange.objects.filter(status="shipped").count(),
        "completed_count": Exchange.objects.filter(status="completed").count(),
        "cancelled_count": Exchange.objects.filter(status="cancelled").count(),
    }

    return render(
        request,
        "dashboard/exchanges.html",
        context,
    )

@owner_or_staff_required
def dashboard_exchange_detail(request, pk):

    exchange = get_object_or_404(
        Exchange.objects.select_related(
            "order",
            "old_product",
            "new_product",
            "return_request",
        ),
        pk=pk,
    )

    if request.method == "POST":

        product_id = request.POST.get("new_product")

        if product_id:

            exchange.new_product = get_object_or_404(
                Product,
                pk=product_id,
            )

        exchange.status = request.POST.get(
            "status",
            exchange.status,
        )

        exchange.courier_name = request.POST.get(
            "courier_name",
            exchange.courier_name,
        )

        exchange.tracking_number = request.POST.get(
            "tracking_number",
            exchange.tracking_number,
        )

        exchange.estimated_delivery = (
            request.POST.get("estimated_delivery")
            or None
        )

        exchange.admin_note = request.POST.get(
            "admin_note",
            exchange.admin_note,
        )

        exchange.save()

        messages.success(
            request,
            "Exchange updated successfully.",
        )

        return redirect(
            "dashboard:dashboard_exchange_detail",
            exchange.id,
        )

    products = Product.objects.filter(
        is_available=True,
    ).order_by("name")

    return render(
        request,
        "dashboard/exchange_detail.html",
        {
            "exchange": exchange,
            "products": products,
        },
    )

@require_POST
@owner_or_staff_required
def complete_exchange(request, pk):

    exchange = get_object_or_404(
        Exchange,
        pk=pk,
    )

    if exchange.status == "completed":

        messages.warning(
            request,
            "Exchange already completed.",
        )

        return redirect(
            "dashboard:dashboard_exchange_detail",
            exchange.id,
        )

    exchange.status = "completed"
    exchange.completed_by = request.user
    exchange.completed_at = timezone.now()

    exchange.save()

    if exchange.old_product:
        exchange.old_product.stock += exchange.quantity
        exchange.old_product.save(
            update_fields=["stock"]
        )

    if exchange.new_product:
        exchange.new_product.stock -= exchange.quantity
        exchange.new_product.save(
            update_fields=["stock"]
        )

    OrderTimeline.objects.create(
        order=exchange.order,
        user=request.user,
        created_by=request.user.username,
        note=(
            f"🔄 Exchange completed.\n"
            f"{exchange.old_product} → {exchange.new_product}"
        ),
    )

    messages.success(
        request,
        "Exchange completed successfully.",
    )

    return redirect(
        "dashboard:dashboard_exchange_detail",
        exchange.id,
    )


@require_POST
@owner_or_staff_required
def cancel_exchange(request, pk):

    exchange = get_object_or_404(
        Exchange,
        pk=pk,
    )

    exchange.status = "cancelled"

    exchange.admin_note = request.POST.get(
        "admin_note",
        exchange.admin_note,
    )

    exchange.save()

    OrderTimeline.objects.create(
        order=exchange.order,
        user=request.user,
        created_by=request.user.username,
        note="❌ Exchange cancelled.",
    )

    messages.success(
        request,
        "Exchange cancelled.",
    )

    return redirect(
        "dashboard:dashboard_exchange_detail",
        exchange.id,
    )

@owner_or_staff_required
def dashboard_replacements(request):

    status = request.GET.get("status")

    replacements = (
        Replacement.objects
        .select_related(
            "old_order",
            "new_order",
            "return_request",
            "completed_by",
        )
        .order_by("-created_at")
    )

    if status:
        replacements = replacements.filter(status=status)

    paginator = Paginator(
        replacements,
        20,
    )

    page = request.GET.get("page")

    page_obj = paginator.get_page(page)

    return render(
        request,
        "dashboard/replacements.html",
        {
            "replacements": page_obj,
            "page_obj": page_obj,
        },
    )
    
@owner_or_staff_required
def dashboard_replacement_detail(request, pk):

    replacement = get_object_or_404(
        Replacement.objects.select_related(
            "old_order",
            "new_order",
            "return_request",
        ),
        pk=pk,
    )

    return render(
        request,
        "dashboard/replacement_detail.html",
        {
            "replacement": replacement,
        },
    )

@require_POST
@owner_or_staff_required
def complete_replacement(request, pk):

    replacement = get_object_or_404(
        Replacement,
        pk=pk,
    )

    replacement.status = "completed"
    replacement.completed_by = request.user
    replacement.completed_at = timezone.now()

    replacement.save()

    OrderTimeline.objects.create(
        order=replacement.old_order,
        user=request.user,
        created_by=request.user.username,
        note="📦 Replacement completed.",
    )

    messages.success(
        request,
        "Replacement completed successfully.",
    )

    return redirect(
        "dashboard:dashboard_replacement_detail",
        replacement.id,
    )

@require_POST
@owner_or_staff_required
def cancel_replacement(request, pk):

    replacement = get_object_or_404(
        Replacement,
        pk=pk,
    )

    replacement.status = "cancelled"

    replacement.admin_note = request.POST.get(
        "admin_note",
        replacement.admin_note,
    )

    replacement.save()

    OrderTimeline.objects.create(
        order=replacement.old_order,
        user=request.user,
        created_by=request.user.username,
        note="❌ Replacement cancelled.",
    )

    messages.success(
        request,
        "Replacement cancelled.",
    )

    return redirect(
        "dashboard:dashboard_replacement_detail",
        replacement.id,
    )

@owner_or_staff_required
def return_review(request, pk):

    return_request = get_object_or_404(
        ReturnRequest.objects.select_related(
            "order",
            "user",
        ).prefetch_related(
            "order__items__product",
            "order__timeline",
        ),
        pk=pk,
    )

    order = return_request.order

    if request.method == "POST":

        resolution = request.POST.get("resolution")
        admin_note = request.POST.get("admin_note", "").strip()

        if not resolution:

            messages.error(
                request,
                "Please select a resolution."
            )

            return redirect(
                "dashboard:return_review",
                pk=pk,
            )

        return_request.admin_note = admin_note

        return_request.resolution = resolution

        # ======================================
        # Reject
        # ======================================

        if resolution == "reject":

            return_request.status = "rejected"

            return_request.save()

            OrderTimeline.objects.create(

                order=order,

                user=request.user,

                created_by=request.user.username,

                note="❌ Return request rejected.",

            )

            messages.success(
                request,
                "Return request rejected."
            )

            return redirect(
                "dashboard:dashboard_returns"
            )

        # ======================================
        # Approve
        # ======================================

        return_request.status = "approved"

        return_request.save()

        OrderTimeline.objects.create(

            order=order,

            user=request.user,

            created_by=request.user.username,

            note=f"✅ Return approved ({resolution.title()}).",

        )

        # ======================================
        # Refund
        # ======================================

        if resolution == "refund":

            Refund.objects.get_or_create(

                order=order,

                return_request=return_request,

                defaults={

                    "amount": order.final_total,

                    "status": "pending",

                },

            )

            OrderTimeline.objects.create(

                order=order,

                user=request.user,

                created_by=request.user.username,

                note="💰 Sent to Refund Center.",

            )

            messages.success(
                request,
                "Refund request moved to Refund Center."
            )

        # ======================================
        # Exchange
        # ======================================

        elif resolution == "exchange":

            OrderTimeline.objects.create(

                order=order,

                user=request.user,

                created_by=request.user.username,

                note="🔄 Exchange request approved.",

            )

            messages.success(
                request,
                "Exchange request approved."
            )

        # ======================================
        # Replacement
        # ======================================

        elif resolution == "replacement":

            OrderTimeline.objects.create(

                order=order,

                user=request.user,

                created_by=request.user.username,

                note="📦 Replacement request approved.",

            )

            messages.success(
                request,
                "Replacement request approved."
            )

        return redirect(
            "dashboard:dashboard_returns"
        )

    return render(

        request,

        "dashboard/return_review.html",

        {

            "return_request": return_request,

            "order": order,

        },

    )