from django.urls import path
from . import views

app_name = "cart"

urlpatterns = [
    path("add/<int:product_id>/", views.cart_add, name="cart_add"),

    path("detail/", views.cart_detail, name="cart_detail"),

    path("remove/<int:product_id>/", views.cart_remove, name="cart_remove"),

    path("update/<int:product_id>/<str:action>/", views.cart_update, name="cart_update"),

    path("checkout/", views.checkout, name="checkout"),

    path("coupon/apply/", views.apply_coupon, name="apply_coupon"),
    
    path("coupon/remove/", views.remove_coupon,name="remove_coupon"),

]