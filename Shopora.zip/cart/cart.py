from decimal import Decimal
import copy
from store.models import Product

class Cart:
    def __init__(self, request):
        self.session = request.session
        
        cart = self.session.get("cart")

        if not cart:
            cart = self.session["cart"] = {}

        self.cart = cart
    
    def add(self, product, quantity=1):

        product_id = str(product.id)

        if product_id not in self.cart:

            self.cart[product_id] = {
                "quantity": quantity
            }

        else:

            self.cart[product_id]["quantity"] += quantity
        
        self.save()
    
    def save(self):
        self.session["cart"] = self.cart
        self.session.modified = True


    # ==============================
    # NEW METHODS
    # ==============================

    def remove(self, product):

        product_id = str(product.id)

        if product_id in self.cart:

            del self.cart[product_id]

            self.save()

    def update(self, product, quantity):

        product_id = str(product.id)

        if product_id in self.cart:

            self.cart[product_id]["quantity"] = quantity

            self.save()

    def __iter__(self):

        product_ids = self.cart.keys()

        products = Product.objects.filter(

            id__in=product_ids

        )

    # Deep copy যাতে session modify না হয়
        cart = copy.deepcopy(self.cart)

        for product in products:

            item = cart[str(product.id)]

            item["product"] = product

            item["price"] = product.price

            item["total_price"] = (

                product.price *

                item["quantity"]

            )

        for item in cart.values():

            yield item
    
    def get_total_price(self):

        return sum(item["price"] * item["quantity"] for item in self)
    
    def __len__(self):
        
        return sum(item["quantity"] for item in self.cart.values())
    
    def clear(self):

        if "cart" in self.session:
            del self.session["cart"]

        self.session.modified = True